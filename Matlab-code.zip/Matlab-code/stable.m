clc;
clear;
close all;

%% Parameters
numNodes = 10000; % Number of sensor nodes
areaSize = 150; % Network area (1500x1500)
initialEnergy = 100; % Initial energy per node
numAnts = 20; % Number of ants
numIterations = 100; % Maximum iterations
alpha = 1; % Pheromone importance
beta = 2; % Distance importance
gamma = 1.5; % Energy importance
decay = 0.5; % Pheromone evaporation rate
earlyStoppingThreshold = 10; % Early stopping if no improvement
transmissionCost = 0.1; % Energy cost for transmission
receptionCost = 0.05; % Energy cost for reception

%% Generate Nodes and Energy
nodes = rand(numNodes, 2) * areaSize; % Random sensor nodes
energy = initialEnergy * ones(1, numNodes); % Initial energy allocation

% Add two permanent nodes at fixed locations
permNodes = [areaSize/4, areaSize/4; 3*areaSize/4, 3*areaSize/4];
nodes = [nodes; permNodes];
energy = [energy, initialEnergy, initialEnergy];

%% Create Visualization
figure;
subplot(1, 2, 1);
scatter(nodes(:,1), nodes(:,2), 100, energy, 'filled');
hold on;
plot(permNodes(1,1), permNodes(1,2), 'bs', 'MarkerSize', 12, 'LineWidth', 2); % Blue square for permanent node 1
plot(permNodes(2,1), permNodes(2,2), 'cs', 'MarkerSize', 12, 'LineWidth', 2); % Cyan square for permanent node 2
colorbar;
title('Select Start and End Node');
xlabel('X-coordinate'); ylabel('Y-coordinate');
grid on;

% Select Start and End Nodes
[x, y] = ginput(2);
[~, startNode] = min(vecnorm(nodes - [x(1), y(1)], 2, 2));
[~, endNode] = min(vecnorm(nodes - [x(2), y(2)], 2, 2));

plot(nodes(startNode,1), nodes(startNode,2), 'go', 'MarkerSize', 10, 'LineWidth', 2);
plot(nodes(endNode,1), nodes(endNode,2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
pause(1);

% Initialize pheromone levels
pheromone = ones(numNodes+2, numNodes+2);

% Compute Distance Matrix
distances = zeros(numNodes+2, numNodes+2);
for i = 1:numNodes+2
    for j = 1:numNodes+2
        distances(i, j) = norm(nodes(i, :) - nodes(j, :));
    end
end

%% ACO Variables
energyConsumed = zeros(1, numIterations);
bestPathsOverall = cell(3, 1); % Store best three paths
bestPathLengths = inf(3, 1); % Store lengths of best three paths
bestPathOverall = [];
bestPathLength = inf;
noImprovementCount = 0;

%% Ant Colony Optimization Algorithm
for iter = 1:numIterations
    paths = cell(numAnts, 1);
    pathLengths = inf(numAnts, 1);
    energyUsedPerIter = zeros(1, numAnts);
    
    for ant = 1:numAnts
        path = startNode;
        visited = false(1, numNodes+2);
        visited(startNode) = true;
        energyUsed = 0;
        
        while path(end) ~= endNode
            current = path(end);
            
            % Compute transition probabilities
            probabilities = ((pheromone(current, :) .^ alpha) .* ...
                             ((1 ./ (distances(current, :) + 1e-6)) .^ beta) .* ...
                             ((energy ./ (max(energy) + 1e-6)) .^ gamma));
            probabilities(visited) = 0; % Prevent revisiting
            
            % Normalize probabilities
            if sum(probabilities) == 0
                nextNode = find(~visited, 1);
                if isempty(nextNode), break; end
            else
                probabilities = probabilities / sum(probabilities);
                nextNode = find(rand < cumsum(probabilities), 1);
            end
            
            % Update path and energy
            path = [path, nextNode];
            visited(nextNode) = true;
            
            energyUsed = energyUsed + distances(current, nextNode) * transmissionCost + receptionCost;
            energy(current) = max(energy(current) - distances(current, nextNode) * transmissionCost, 0);
            energy(nextNode) = max(energy(nextNode) - receptionCost, 0);
        end
        
        % If valid path found, store it
        if path(end) == endNode
            paths{ant} = path;
            pathLengths(ant) = sum(distances(sub2ind(size(distances), path(1:end-1), path(2:end)))); 
            energyUsedPerIter(ant) = energyUsed;
        end
    end
    
    % Find the best path in this iteration
    validPaths = find(~isinf(pathLengths));
    if ~isempty(validPaths)
        [minLength, bestIdx] = min(pathLengths(validPaths));
        bestPath = paths{validPaths(bestIdx)};
        
        % Update the best paths if the current path is better
        if minLength < bestPathLengths(1)
            bestPathsOverall{3} = bestPathsOverall{2};
            bestPathLengths(3) = bestPathLengths(2);
            bestPathsOverall{2} = bestPathsOverall{1};
            bestPathLengths(2) = bestPathLengths(1);
            bestPathsOverall{1} = bestPath;
            bestPathLengths(1) = minLength;
        elseif minLength < bestPathLengths(2)
            bestPathsOverall{3} = bestPathsOverall{2};
            bestPathLengths(3) = bestPathLengths(2);
            bestPathsOverall{2} = bestPath;
            bestPathLengths(2) = minLength;
        elseif minLength < bestPathLengths(3)
            bestPathsOverall{3} = bestPath;
            bestPathLengths(3) = minLength;
        end
        
        if minLength < bestPathLength
            bestPathOverall = bestPath;
            bestPathLength = minLength;
            noImprovementCount = 0;
        else
            noImprovementCount = noImprovementCount + 1;
        end
    else
        noImprovementCount = noImprovementCount + 1;
    end
    
    % Early stopping condition
    if noImprovementCount >= earlyStoppingThreshold
        fprintf('Early stopping at iteration %d.\n', iter);
        break;
    end
    
    % Update pheromone levels
    pheromone = (1 - decay) * pheromone;
    if ~isempty(bestPath)
        for i = 1:length(bestPath)-1
            pheromone(bestPath(i), bestPath(i+1)) = pheromone(bestPath(i), bestPath(i+1)) + (1 / bestPathLength);
        end
    end
    
    energyConsumed(iter) = mean(energyUsedPerIter(validPaths));
    
    % Update Network Visualization
    subplot(1, 2, 1);
    cla;
    scatter(nodes(:,1), nodes(:,2), 100, energy, 'filled');
    colorbar;
    hold on;
    plot(nodes(startNode,1), nodes(startNode,2), 'go', 'MarkerSize', 10, 'LineWidth', 2);
    plot(nodes(endNode,1), nodes(endNode,2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);
    
    for ant = 1:numAnts
        if ~isempty(paths{ant}) && paths{ant}(end) == endNode
            for i = 1:length(paths{ant})-1
                plot([nodes(paths{ant}(i),1), nodes(paths{ant}(i+1),1)], ...
                     [nodes(paths{ant}(i),2), nodes(paths{ant}(i+1),2)], 'k-', 'LineWidth', 0.5);
            end
        end
    end
    
    if ~isempty(bestPathOverall)
        for i = 1:length(bestPathOverall)-1
            plot([nodes(bestPathOverall(i),1), nodes(bestPathOverall(i+1),1)], ...
                 [nodes(bestPathOverall(i),2), nodes(bestPathOverall(i+1),2)], 'r-', 'LineWidth', 2);
        end
    end
    drawnow;
    
    % Energy consumption graph
    subplot(1, 2, 2);
    plot(1:iter, energyConsumed(1:iter), 'b-o', 'LineWidth', 2);
    title('Energy Consumption per Iteration');
    xlabel('Iteration');
    ylabel('Energy Consumed');
    grid on;
    
    fprintf('Iteration %d: Best Path Length = %.2f, Energy Consumption = %.2f\n', iter, bestPathLength, energyConsumed(iter));
end

% Finalize the results
fprintf('Best Path Overall Length: %.2f\n', bestPathLength);
fprintf('Best Path Nodes: %s\n', mat2str(bestPathOverall));

% Plot the best path found
figure;
scatter(nodes(:,1), nodes(:,2), 100, energy, 'filled');
colorbar;
hold on;
plot(nodes(startNode,1), nodes(startNode,2), 'go', 'MarkerSize', 10, 'LineWidth', 2);
plot(nodes(endNode,1), nodes(endNode,2), 'ro', 'MarkerSize', 10, 'LineWidth', 2);

% Plot the best three paths
for j = 1:3
    if ~isempty(bestPathsOverall{j})
        for i = 1:length(bestPathsOverall{j})-1
            plot([nodes(bestPathsOverall{j}(i),1), nodes(bestPathsOverall{j}(i+1),1)], ...
                 [nodes(bestPathsOverall{j}(i),2), nodes(bestPathsOverall{j}(i+1),2)], 'm--', 'LineWidth', 1.5);
        end
    end
end

title('Best Path Found by ACO and Best Three Paths');
xlabel('X-coordinate');
ylabel('Y-coordinate');
grid on;
hold off;

% Display energy consumption graph
figure;
plot(1:iter, energyConsumed(1:iter), 'b-o', 'LineWidth', 2);
title('Energy Consumption per Iteration');
xlabel('Iteration');
ylabel('Energy Consumed');
grid on;

% Save results if needed
save('aco_results.mat', 'bestPathsOverall', 'bestPathLengths', 'bestPathOverall', 'bestPathLength', 'energyConsumed');